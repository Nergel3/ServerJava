package iut.rt.hachettp;
/**
 * Le code ci-dessous correspont au code de l'exception http.
 * 
 * @author Alexandre Negrel
 * @date 27/02/2019
 */
public class HTTPException extends Exception {
	
	public HTTPException(String msg) {
		super(msg);
	}
}
