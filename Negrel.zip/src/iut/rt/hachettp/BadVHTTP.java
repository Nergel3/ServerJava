package iut.rt.hachettp;
/**
 * Le code ci-dessous correspont au code de la mauvaise version http.
 * 
 * @author Alexandre Negrel
 * @date 28/03/2019
 */
public class BadVHTTP extends HTTPException {

	public BadVHTTP(String msg) {
		super(msg);
	}

}
